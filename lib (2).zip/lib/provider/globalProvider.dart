import 'package:flutter/material.dart';
import 'package:shop_app/models/product_model.dart';

class Global_provider extends ChangeNotifier {
  List<ProductModel> products = [];
  List<ProductModel> cartItems = [];
  List<ProductModel> favoriteItems = [];

  // BottomNavigation
  int currentIdx = 0;

  void setProducts(List<ProductModel> data) {
    products = data;
    notifyListeners(); // UI-д
  }

  void addCartItems(ProductModel item) {
    if (cartItems.contains(item)) {
      cartItems.remove(item);
    } else {
      item.count = 1; 
      cartItems.add(item);
    }
    notifyListeners(); 
  }

  // ❤️
  void toggleFavorite(ProductModel item) {
    if (favoriteItems.contains(item)) {
      favoriteItems.remove(item);
    } else {
      favoriteItems.add(item);
    }
    notifyListeners();
  }

  bool isFavorite(ProductModel item) {
    return favoriteItems.contains(item);
  }

  void changeCurrentIdx(int idx) {
    currentIdx = idx;
    notifyListeners();
  }

  // ➕ 
  void increaseCount(ProductModel product) {
    product.count = (product.count ?? 1) + 1;
    notifyListeners();
  }

  // ➖ 
  void decreaseCount(ProductModel product) {
    if ((product.count ?? 1) > 1) {
      product.count = product.count! - 1;
    } else {
      cartItems.remove(product); // 0 болбол сагснаас устгах
    }
    notifyListeners();
  }
}
