import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/users.dart';            
import '../provider/globalProvider.dart'; 


class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  @override
  Widget build(BuildContext context) {
    final user = UserSession.currentUser; // login хийсэн хэрэглэгч

    return Scaffold(
      appBar: AppBar(
        title: const Text('Миний мэдээлэл'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Гарах',
            onPressed: () {
              
              setState(() {
                UserSession.logout();
              });

              //  Profile tab доторх LoginPage-г ачаалуулахын тулд tab index-г шинэчилнэ
              Provider.of<Global_provider>(context, listen: false).changeCurrentIdx(3);
            },
          ),
        ],
      ),

      body: user == null
          ? const Center(child: Text('Нэвтрээгүй байна.'))

          : Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Хувийн мэдээлэл',
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 20),

                  _infoRow('Нэр', '${user.firstname} ${user.lastname}'),
                  _infoRow('Имэйл', user.email),
                  _infoRow('Утас', user.phone),
                  _infoRow('Хот', user.city),
                ],
              ),
            ),
    );
  }


  Widget _infoRow(String title, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
 
          SizedBox(
            width: 100,
            child: Text(
              '$title:',
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
          ),
          Expanded(child: Text(value)),
        ],
      ),
    );
  }
}
