import 'package:flutter/material.dart';
import '../models/users.dart';       
import 'profile_page.dart';         

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {

  final _usernameController = TextEditingController();
  final _passwordController = TextEditingController();


  String? _error;

  void _handleLogin() async {
    final username = _usernameController.text.trim();  
    final password = _passwordController.text.trim();   

    final success = await UserSession.login(username, password); // login шалгах

    if (success) {
      setState(() => _error = null); 
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const ProfilePage()),
      );
    } else {
      setState(() => _error = 'Нэвтрэх нэр эсвэл нууц үг буруу байна.');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Нэвтрэх')), // AppBar title
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // 🧑 Нэвтрэх нэр
            TextField(
              controller: _usernameController,
              decoration: const InputDecoration(labelText: 'Нэвтрэх нэр'),
            ),
            // 🔒 Нууц үг
            TextField(
              controller: _passwordController,
              obscureText: true,
              decoration: const InputDecoration(labelText: 'Нууц үг'),
            ),
            const SizedBox(height: 20),
            // 🔘 Нэвтрэх товч
            ElevatedButton(
              onPressed: _handleLogin,
              child: const Text('Нэвтрэх'),
            ),
            // ⚠️ Алдаа байвал мессеж харуулах хэсэг
            if (_error != null) ...[
              const SizedBox(height: 10),
              Text(_error!, style: const TextStyle(color: Colors.red)),
            ]
          ],
        ),
      ),
    );
  }
}
